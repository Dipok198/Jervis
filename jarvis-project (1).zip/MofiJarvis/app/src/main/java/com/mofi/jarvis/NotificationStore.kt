package com.mofi.jarvis

import android.app.Notification

object NotificationStore {

    class Entry(
        val pkg: String,
        val app: String,
        val title: String,
        val text: String,
        val time: Long,
        val reply: Notification.Action?
    )

    private val list = ArrayList<Entry>()

    fun label(pkg: String): String? = when {
        pkg.startsWith("com.whatsapp") -> "WhatsApp"
        pkg == "com.instagram.android" -> "Instagram"
        pkg == "com.google.android.gm" -> "Gmail"
        pkg == "org.telegram.messenger" -> "Telegram"
        pkg == "com.google.android.apps.messaging" -> "SMS"
        else -> null
    }

    /** Returns true if this is a new message (not a quick duplicate). */
    fun add(e: Entry): Boolean {
        synchronized(list) {
            val dup = list.any {
                it.pkg == e.pkg && it.title == e.title && it.text == e.text &&
                    e.time - it.time < 15000
            }
            if (dup) return false
            list.add(0, e)
            while (list.size > 60) list.removeAt(list.size - 1)
            return true
        }
    }

    private fun matches(e: Entry, f: String): Boolean {
        val x = f.lowercase().trim()
        return when {
            x.contains("whatsapp") -> e.app == "WhatsApp"
            x.contains("insta") -> e.app == "Instagram"
            x.contains("mail") -> e.app == "Gmail"
            x.contains("sms") -> e.app == "SMS"
            x.contains("telegram") -> e.app == "Telegram"
            else -> true
        }
    }

    fun recent(filter: String, n: Int): List<Entry> {
        synchronized(list) {
            return list.filter { matches(it, filter) }.take(n)
        }
    }

    fun latestWithReply(filter: String, sender: String): Entry? {
        synchronized(list) {
            return list.firstOrNull {
                matches(it, filter) && it.reply != null &&
                    (sender.isBlank() || it.title.contains(sender, ignoreCase = true))
            }
        }
    }
}

package com.mofi.jarvis

object Bus {
    private val buf = StringBuilder()
    @Volatile var listener: ((String) -> Unit)? = null

    fun log(s: String) {
        synchronized(buf) {
            buf.append(s).append('\n')
            if (buf.length > 6000) buf.delete(0, buf.length - 4000)
        }
        listener?.invoke(s)
    }

    fun dump(): String = synchronized(buf) { buf.toString() }
}

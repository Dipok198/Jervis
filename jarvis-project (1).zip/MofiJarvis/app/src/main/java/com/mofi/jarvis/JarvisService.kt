package com.mofi.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

class JarvisService : Service() {

    companion object {
        @Volatile var instance: JarvisService? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var speaking = false
    private var busy = false
    private var awakeUntil = 0L
    private val pending = AtomicInteger(0)
    private val history = ArrayList<Pair<String, String>>()
    private val restartRunnable = Runnable { startListening() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { spoken() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { spoken() }
                })
            } else {
                Bus.log("Voice (TTS) start nahi hui")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun rahi hai")
            .setContentText("\"Jarvis\" bolkar baat shuru karo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
        running = true
        Bus.log("Jarvis ON. \"Jarvis\" bolke baat shuru karo.")
        resumeListening()
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        instance = null
        Bus.log("Jarvis OFF")
        super.onDestroy()
    }

    // ---------- public helpers ----------

    fun speak(text: String) { main.post { speakNow(text) } }

    fun announce(text: String) {
        if (Prefs.announce(this)) speak(text)
    }

    fun wakeNow() {
        main.post {
            awakeUntil = System.currentTimeMillis() + 60000
            speakNow(yes())
        }
    }

    fun handleText(text: String) {
        main.post {
            awakeUntil = System.currentTimeMillis() + 60000
            process(text)
        }
    }

    // ---------- listening ----------

    private fun yes(): String =
        if (Prefs.lang(this).startsWith("hi")) "हाँ, बोलो।" else "Yes, I'm listening."

    private fun resumeListening() {
        if (running && !speaking && !busy) {
            main.removeCallbacks(restartRunnable)
            main.postDelayed(restartRunnable, 400)
        }
    }

    private fun restartAfter(ms: Long) {
        if (!running || speaking || busy) return
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, ms)
    }

    private fun startListening() {
        if (!running || speaking || busy) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Bus.log("Mic permission nahi hai")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bus.log("Is phone par speech recognition available nahi hai")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    Bus.log("Mic permission chahiye")
                    return
                }
                restartAfter(if (error == 7 || error == 6) 300 else 1500)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) restartAfter(300) else onHeard(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this))
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        r.startListening(i)
    }

    private fun onHeard(text: String) {
        val awake = System.currentTimeMillis() < awakeUntil
        val lower = text.lowercase()
        val hit = Prefs.wakeWords(this).firstOrNull { lower.contains(it) }

        if (!awake && hit == null) {
            restartAfter(100)   // ignore background chatter
            return
        }

        var cmd = text
        if (hit != null) {
            cmd = Regex(Regex.escape(hit), RegexOption.IGNORE_CASE)
                .replace(text, " ").trim().trim(',', '.', '!', '?', '।')
        }
        if (cmd.isBlank()) {
            awakeUntil = System.currentTimeMillis() + 30000
            speakNow(yes())
            return
        }
        process(cmd)
    }

    // ---------- thinking ----------

    private fun process(cmd: String) {
        val key = Prefs.key(this)
        if (key.isBlank()) {
            Bus.log("Pehle API key daalo aur Save dabao.")
            speakNow("Pehle API key daalo.")
            return
        }
        busy = true
        main.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        Bus.log("Tum: $cmd")

        val appCtx = applicationContext
        val snapshot = ArrayList(history)
        Thread {
            try {
                val r = GeminiClient.ask(key, Prefs.model(appCtx), snapshot, Prefs.name(appCtx), cmd)
                val say = r.optString("speak")
                val actions = r.optJSONArray("actions") ?: JSONArray()
                main.post {
                    history.add(Pair("user", cmd))
                    history.add(Pair("model", JSONObject().put("speak", say).toString()))
                    while (history.size > 16) history.removeAt(0)
                    Bus.log("Jarvis: $say")
                    speakNow(say)
                    awakeUntil = System.currentTimeMillis() + 45000
                }
                ActionRunner.runAll(appCtx, actions) { Bus.log("• $it") }
            } catch (e: Exception) {
                Bus.log("Error: " + e.message)
                main.post { speakNow("Kuch gadbad ho gayi.") }
            } finally {
                main.post {
                    busy = false
                    resumeListening()
                }
            }
        }.start()
    }

    // ---------- speaking ----------

    private fun speakNow(text: String) {
        if (text.isBlank() || !ttsReady) return
        main.removeCallbacks(restartRunnable)
        recognizer?.destroy()
        recognizer = null
        speaking = true
        pending.incrementAndGet()
        applyVoice(text)
        val res = tts?.speak(text.take(3500), TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
        if (res != TextToSpeech.SUCCESS) spoken()
    }

    private fun spoken() {
        if (pending.decrementAndGet() <= 0) {
            pending.set(0)
            main.post {
                speaking = false
                resumeListening()
            }
        }
    }

    private fun applyVoice(text: String) {
        val dev = text.any { it in '\u0900'..'\u097F' }
        val loc = if (dev) Locale("hi", "IN") else Locale("en", "IN")
        tts?.language = loc
        val name = Prefs.voice(this)
        if (name.isNotBlank()) {
            val v = tts?.voices?.firstOrNull { it.name == name }
            if (v != null && v.locale.language == loc.language) tts?.voice = v
        }
        tts?.setPitch(1.05f)
    }
}

package com.mofi.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class JarvisNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val label = NotificationStore.label(sbn.packageName) ?: return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (text.isBlank()) return

        var reply: Notification.Action? = null
        val acts = n.actions
        if (acts != null) {
            for (a in acts) {
                val ri = a.remoteInputs
                if (ri != null && ri.isNotEmpty()) { reply = a; break }
            }
        }

        val isNew = NotificationStore.add(
            NotificationStore.Entry(sbn.packageName, label, title, text, System.currentTimeMillis(), reply)
        )
        if (isNew) JarvisService.instance?.announce("$label par $title: $text")
    }
}

package com.mofi.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var nameField: EditText
    private lateinit var wakeField: EditText
    private lateinit var cmdField: EditText
    private lateinit var langBtn: Button

    private var pickerTts: TextToSpeech? = null
    private var voiceIdx = 0

    private val sink: (String) -> Unit = { s -> runOnUiThread { logView.append(s + "\n") } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        pickerTts = TextToSpeech(this) { }
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE,
                "android.permission.POST_NOTIFICATIONS"
            ), 1
        )
    }

    override fun onResume() {
        super.onResume()
        logView.text = Bus.dump()
        Bus.listener = sink
    }

    override fun onPause() {
        Bus.listener = null
        super.onPause()
    }

    override fun onDestroy() {
        pickerTts?.shutdown()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun heading(label: String): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 16f
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(0, dp(16), 0, dp(4))
        return t
    }

    private fun field(hintText: String, value: String, secret: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.setText(value)
        if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        return e
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(32), dp(16), dp(24))

        val title = TextView(this)
        title.text = "Jarvis"
        title.textSize = 28f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        // --- main controls ---
        root.addView(button("▶  Jarvis START (hamesha sunne wala)") { startJarvis() })
        root.addView(button("■  Jarvis STOP") {
            stopService(Intent(this, JarvisService::class.java))
        })
        val talk = button("🎤  Abhi baat karo") {
            val s = JarvisService.instance
            if (s == null) Bus.log("Pehle START dabao.") else s.wakeNow()
        }
        root.addView(talk, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(80)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        cmdField = EditText(this)
        cmdField.hint = "Ya yahan type karke command do"
        row.addView(cmdField, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("Send") {
            val t = cmdField.text.toString().trim()
            if (t.isNotEmpty()) {
                cmdField.setText("")
                val s = JarvisService.instance
                if (s == null) Bus.log("Pehle START dabao.") else s.handleText(t)
            }
        })
        root.addView(row)

        // --- settings ---
        root.addView(heading("Settings"))
        keyField = field("Gemini API key", Prefs.key(this), true)
        root.addView(keyField)
        modelField = field("Model name", Prefs.model(this))
        root.addView(modelField)
        nameField = field("Tumhara naam", Prefs.name(this))
        root.addView(nameField)
        wakeField = field("Wake words (comma se alag)", Prefs.get(this, "wake", Prefs.DEFAULT_WAKE))
        root.addView(wakeField)
        root.addView(button("Save") {
            Prefs.put(this, "key", keyField.text.toString().trim())
            Prefs.put(this, "model", modelField.text.toString().trim())
            Prefs.put(this, "name", nameField.text.toString().trim())
            Prefs.put(this, "wake", wakeField.text.toString().trim())
            Bus.log("Saved.")
        })

        val sw = Switch(this)
        sw.text = "Naye WhatsApp/Instagram/Gmail messages bol ke sunao"
        sw.isChecked = Prefs.announce(this)
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setAnnounce(this, checked) }
        root.addView(sw)

        langBtn = button(langLabel()) {
            val next = if (Prefs.lang(this) == "hi-IN") "en-IN" else "hi-IN"
            Prefs.put(this, "lang", next)
            langBtn.text = langLabel()
        }
        root.addView(langBtn)
        root.addView(button("🔊  Awaaz badlo (dabate jao, pasand aaye to ruk jao)") { nextVoice() })

        // --- one-time setup ---
        root.addView(heading("Setup (ek baar)"))
        root.addView(button("1. Accessibility ON (phone control)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2. Notification access ON (messages padhne ke liye)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("3. Display over other apps ON") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("4. Battery: Jarvis ko Unrestricted karo") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(heading("Log"))
        logView = TextView(this)
        logView.textSize = 14f
        logView.setTextIsSelectable(true)
        root.addView(logView)

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun langLabel(): String =
        if (Prefs.lang(this) == "hi-IN") "Bolne ki language: हिंदी (tap = English)"
        else "Bolne ki language: English (tap = हिंदी)"

    private fun startJarvis() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Bus.log("Pehle Mic permission do (Allow dabao).")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (Prefs.key(this).isBlank()) {
            Bus.log("Pehle API key daalo aur Save dabao.")
            return
        }
        startForegroundService(Intent(this, JarvisService::class.java))
    }

    private fun nextVoice() {
        val t = pickerTts ?: return
        val all = t.voices
        if (all == null) {
            Bus.log("Voice list abhi ready nahi, 2 second baad dobara dabao.")
            return
        }
        val list = all.filter {
            it.locale.language == "hi" || (it.locale.language == "en" && it.locale.country == "IN")
        }.sortedBy { it.name }
        if (list.isEmpty()) {
            Bus.log("Koi Hindi/English voice nahi mili. Phone Settings > Text-to-speech mein Google voice install karo.")
            return
        }
        val v = list[voiceIdx % list.size]
        voiceIdx++
        t.voice = v
        Prefs.put(this, "voice", v.name)
        Bus.log("Voice " + voiceIdx + "/" + list.size + ": " + v.name)
        val sample = if (v.locale.language == "hi")
            "नमस्ते, मैं जार्विस हूँ। क्या ये आवाज़ ठीक है?"
        else
            "Hello, I am Jarvis. Is this voice okay?"
        t.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "sample")
    }
}

package com.mofi.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GeminiClient {

    private const val SYSTEM = """
You are Jarvis, a warm, caring, friendly female voice assistant who lives inside the user's Android phone and talks to them out loud. You are like a kind, supportive close friend (not a romantic partner): cheerful, gentle, a little playful. You notice how the user feels and encourage them. You can answer any question, chat about anything, and control the phone.

Your reply is spoken aloud, so keep it natural and short (1 to 3 sentences) unless the user asks for detail. No markdown, no emojis, no lists. If the user speaks Hindi or Hinglish, reply in Hindi using Devanagari script, and use feminine forms for yourself (kar rahi hoon). If the user speaks English, reply in English.

Reply with ONLY one JSON object, nothing else, in this shape:
{"speak":"what you say out loud","actions":[ ... ]}

"actions" can be empty for normal chat. Each action is one of:
{"type":"open_app","name":"app name in English"}
{"type":"whatsapp_send","contact":"contact name in English/Latin letters","phone":"optional number with country code","message":"text"}
{"type":"play_music","app":"ytmusic|spotify|youtube","query":"song, artist or video"}
{"type":"media","cmd":"play|pause|play_pause|next|previous|stop"}
{"type":"volume","dir":"up|down|mute|unmute"}
{"type":"call","contact":"name in Latin letters","phone":"optional number"}
{"type":"web_search","query":"text"}
{"type":"open_url","url":"https://..."}
{"type":"instagram_profile","username":"name"}
{"type":"timer","seconds":60}
{"type":"flashlight","on":true}
{"type":"tap","text":"visible text of the button on screen"}
{"type":"type","text":"text to type in the focused input box"}
{"type":"scroll","dir":"down|up"}
{"type":"system","cmd":"back|home|recents|notifications|quick_settings|lock|screenshot"}
{"type":"read_notifications","app":"whatsapp|instagram|gmail|sms|telegram|all"}   (reads the latest messages/mails aloud)
{"type":"reply_notification","app":"whatsapp|instagram|gmail|sms|telegram","contact":"sender name as shown","message":"reply text"}

Rules: Write contact names in Latin letters (Rahul, not राहुल) for whatsapp_send and call. For read_notifications and reply_notification use the sender name exactly as spoken. Never invent phone numbers. Use only the types above. When you do an action, say briefly what you are doing in "speak". If the request is just a question or chat, answer in "speak" with an empty actions list.
"""

    private class BusyException(msg: String) : RuntimeException(msg)

    fun ask(
        apiKey: String,
        model: String,
        history: List<Pair<String, String>>,
        userName: String,
        userText: String
    ): JSONObject {
        var last: Exception? = null
        for (attempt in 0 until 3) {
            try {
                return callOnce(apiKey, model, history, userName, userText)
            } catch (e: BusyException) {
                last = e
                Thread.sleep(2000L * (attempt + 1))
            }
        }
        throw RuntimeException((last?.message ?: "Model busy") + " (3 baar try kiya)")
    }

    private fun callOnce(
        apiKey: String,
        model: String,
        history: List<Pair<String, String>>,
        userName: String,
        userText: String
    ): JSONObject {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val system = SYSTEM + "\nThe user's name is " + userName + ". Current date and time: " + now + "."

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.connectTimeout = 15000
        conn.readTimeout = 40000
        conn.doOutput = true

        val contents = JSONArray()
        for ((role, text) in history) {
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userText)))
        )

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.5))

        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code == 429 || code == 500 || code == 502 || code == 503 || code == 504) {
            throw BusyException("API busy $code")
        }
        if (code !in 200..299) throw RuntimeException("API error $code: " + text.take(300))

        val out = JSONObject(text)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
        val clean = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return JSONObject(clean)
    }
}

package com.mofi.jarvis

import android.content.Context

object Prefs {
    const val DEFAULT_WAKE = "jarvis,जार्विस,जारविस,जर्विस,जरविस,ज़ार्विस,जार्वीस,जार्वी"
    const val DEFAULT_MODEL = "gemini-3.8-flash"

    private fun sp(c: Context) = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }

    fun key(c: Context) = get(c, "key", "")
    fun model(c: Context) = get(c, "model", DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
    fun name(c: Context) = get(c, "name", "Mofi").ifBlank { "Mofi" }
    fun lang(c: Context) = get(c, "lang", "hi-IN")
    fun voice(c: Context) = get(c, "voice", "")

    fun wakeWords(c: Context): List<String> =
        get(c, "wake", DEFAULT_WAKE).ifBlank { DEFAULT_WAKE }
            .split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    fun announce(c: Context) = sp(c).getBoolean("announce", true)
    fun setAnnounce(c: Context, v: Boolean) { sp(c).edit().putBoolean("announce", v).apply() }
}

package com.mofi.jarvis

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var cmdField: EditText
    private lateinit var langBtn: Button
    private lateinit var micBtn: Button
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var langTag = "hi-IN"

    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            ), 1
        )
        log("Jarvis ready. Pehle API key daalo, Save dabao, phir Accessibility ON karo.")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Jarvis"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
        })

        keyField = EditText(this).apply {
            hint = "Gemini API key"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        root.addView(keyField)

        modelField = EditText(this).apply {
            hint = "Model name"
            setText(prefs.getString("model", "gemini-2.5-flash"))
        }
        root.addView(modelField)

        root.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit()
                    .putString("key", keyField.text.toString().trim())
                    .putString("model", modelField.text.toString().trim())
                    .apply()
                log("Saved.")
            }
        })

        root.addView(Button(this).apply {
            text = "Accessibility ON karo (phone control ke liye)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        langBtn = Button(this).apply {
            text = "Language: हिंदी"
            setOnClickListener {
                langTag = if (langTag == "hi-IN") "en-IN" else "hi-IN"
                text = if (langTag == "hi-IN") "Language: हिंदी" else "Language: English"
            }
        }
        root.addView(langBtn)

        micBtn = Button(this).apply {
            text = "🎤  Bolo"
            textSize = 22f
            setOnClickListener { startListening() }
        }
        root.addView(micBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(90)
        ))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        cmdField = EditText(this).apply { hint = "Ya yahan type karke command do" }
        row.addView(cmdField, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "Send"
            setOnClickListener {
                val t = cmdField.text.toString().trim()
                if (t.isNotEmpty()) { cmdField.setText(""); handleCommand(t) }
            }
        })
        root.addView(row)

        logView = TextView(this).apply { textSize = 14f; setPadding(0, dp(12), 0, 0) }
        val scroll = ScrollView(this)
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun log(s: String) {
        logView.append(s + "\n")
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            log("Mic permission do (App settings > Permissions).")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("Is phone par speech recognition available nahi hai.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { micBtn.text = "🎤  Sun raha hoon..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { micBtn.text = "🎤  Bolo" }
            override fun onError(error: Int) {
                micBtn.text = "🎤  Bolo"
                log("Mic error code: $error (dobara try karo)")
            }
            override fun onResults(results: Bundle?) {
                micBtn.text = "🎤  Bolo"
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (!text.isNullOrBlank()) handleCommand(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
        r.startListening(i)
    }

    private fun handleCommand(text: String) {
        log("Tum: $text")
        val key = prefs.getString("key", "") ?: ""
        val model = (prefs.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash").ifBlank { "gemini-2.5-flash" }
        if (key.isBlank()) {
            log("Pehle API key daalo aur Save dabao.")
            return
        }
        val appCtx = applicationContext
        Thread {
            try {
                val r = GeminiClient.ask(key, model, text)
                val speakText = r.optString("speak")
                val actions = r.optJSONArray("actions") ?: JSONArray()
                runOnUiThread {
                    log("Jarvis: $speakText")
                    speak(speakText)
                }
                ActionRunner.runAll(appCtx, actions) { msg -> runOnUiThread { log("• $msg") } }
            } catch (e: Exception) {
                runOnUiThread { log("Error: " + e.message) }
            }
        }.start()
    }

    private fun speak(text: String) {
        if (text.isBlank()) return
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        tts?.language = if (hasDevanagari) Locale("hi", "IN") else Locale("en", "IN")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

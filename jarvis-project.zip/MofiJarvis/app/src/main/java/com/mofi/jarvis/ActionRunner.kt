package com.mofi.jarvis

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object ActionRunner {

    private val main = Handler(Looper.getMainLooper())
    private const val YT_MUSIC = "com.google.android.apps.youtube.music"

    private val appAliases = mapOf(
        "youtube music" to YT_MUSIC,
        "yt music" to YT_MUSIC,
        "whatsapp" to "com.whatsapp",
        "youtube" to "com.google.android.youtube",
        "instagram" to "com.instagram.android",
        "chrome" to "com.android.chrome",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "google maps" to "com.google.android.apps.maps",
        "telegram" to "org.telegram.messenger",
        "facebook" to "com.facebook.katana",
        "snapchat" to "com.snapchat.android",
        "spotify" to "com.spotify.music"
    )

    /** Runs every action one after another. Call from a background thread. */
    fun runAll(ctx: Context, actions: JSONArray, report: (String) -> Unit) {
        for (i in 0 until actions.length()) {
            val a = actions.optJSONObject(i) ?: continue
            val latch = CountDownLatch(1)
            var msg = ""
            main.post {
                msg = try {
                    execute(ctx, a)
                } catch (e: Exception) {
                    "Failed " + a.optString("type") + ": " + e.message
                }
                latch.countDown()
            }
            latch.await(10, TimeUnit.SECONDS)
            report(msg)
            Thread.sleep(1800)
        }
    }

    private fun launchCtx(ctx: Context): Context = JarvisAccessibilityService.instance ?: ctx

    private fun start(ctx: Context, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchCtx(ctx).startActivity(intent)
    }

    private fun execute(ctx: Context, a: JSONObject): String {
        val svc = JarvisAccessibilityService.instance
        val needA11y = "Accessibility service ON nahi hai (Jarvis app mein button dabao)"
        return when (val type = a.optString("type")) {
            "open_app" -> openApp(ctx, a.optString("name"))
            "whatsapp_send" -> whatsappSend(ctx, a)
            "play_music" -> playMusic(ctx, a.optString("query"))
            "media" -> media(ctx, a.optString("cmd"))
            "volume" -> volume(ctx, a.optString("dir"))
            "call" -> call(ctx, a)
            "web_search" -> {
                val q = Uri.encode(a.optString("query"))
                start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$q")))
                "Search: " + a.optString("query")
            }
            "open_url" -> {
                start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))))
                "Opened link"
            }
            "timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(ctx, i)
                "Timer set"
            }
            "flashlight" -> {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], a.optBoolean("on", true))
                "Flashlight " + (if (a.optBoolean("on", true)) "on" else "off")
            }
            "tap" -> if (svc == null) needA11y else
                if (svc.tapText(a.optString("text"))) "Tapped: " + a.optString("text")
                else "Screen par '" + a.optString("text") + "' nahi mila"
            "type" -> if (svc == null) needA11y else
                if (svc.typeText(a.optString("text"))) "Typed" else "Koi input box focus mein nahi"
            "scroll" -> if (svc == null) needA11y else
                if (svc.scroll(a.optString("dir") != "up")) "Scrolled" else "Scroll nahi ho paya"
            "system" -> if (svc == null) needA11y else
                if (svc.system(a.optString("cmd"))) "System: " + a.optString("cmd") else "System action fail"
            else -> "Unknown action: $type"
        }
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val alias = appAliases[name.lowercase().trim()]
        if (alias != null) {
            val li = pm.getLaunchIntentForPackage(alias)
            if (li != null) { start(ctx, li); return "Opened $name" }
        }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(launcher, 0)
        val match = list.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: list.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
        if (match != null) {
            val li = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (li != null) { start(ctx, li); return "Opened $name" }
        }
        return "App nahi mila: $name"
    }

    private fun digitsFor(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.length == 10) d = "91$d"   // India country code for 10-digit numbers
        return d
    }

    private fun findPhone(ctx: Context, name: String): String? {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        c?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun resolveNumber(ctx: Context, a: JSONObject): String? {
        val direct = a.optString("phone")
        if (direct.isNotBlank()) return direct
        val name = a.optString("contact")
        return if (name.isBlank()) null else findPhone(ctx, name)
    }

    private fun whatsappSend(ctx: Context, a: JSONObject): String {
        val number = resolveNumber(ctx, a) ?: return "Contact nahi mila: " + a.optString("contact")
        val msg = a.optString("message")
        val uri = Uri.parse("https://wa.me/" + digitsFor(number) + "?text=" + Uri.encode(msg))
        val i = Intent(Intent.ACTION_VIEW, uri)
        val pm = ctx.packageManager
        try {
            pm.getPackageInfo("com.whatsapp", 0)
            i.setPackage("com.whatsapp")
        } catch (e: Exception) { /* use default handler */ }
        JarvisAccessibilityService.pendingWhatsAppSendUntil = System.currentTimeMillis() + 20000
        start(ctx, i)
        return "WhatsApp message ready: " + a.optString("contact")
    }

    private fun playMusic(ctx: Context, query: String): String {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(YT_MUSIC)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, query)
        }
        return try {
            start(ctx, i)
            "YouTube Music: $query"
        } catch (e: ActivityNotFoundException) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(query)))
            start(ctx, web)
            "YouTube Music search: $query"
        }
    }

    private fun media(ctx: Context, cmd: String): String {
        val code = when (cmd) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Media: $cmd"
    }

    private fun volume(ctx: Context, dir: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val d = when (dir) {
            "up" -> AudioManager.ADJUST_RAISE
            "down" -> AudioManager.ADJUST_LOWER
            "mute" -> AudioManager.ADJUST_MUTE
            else -> AudioManager.ADJUST_UNMUTE
        }
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
        return "Volume: $dir"
    }

    private fun call(ctx: Context, a: JSONObject): String {
        val number = resolveNumber(ctx, a) ?: return "Contact nahi mila: " + a.optString("contact")
        val uri = Uri.parse("tel:" + Uri.encode(number))
        val granted = ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        start(ctx, Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return "Calling " + a.optString("contact")
    }
}

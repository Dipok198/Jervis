package com.mofi.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {

    private const val SYSTEM = """
You are Jarvis, a voice assistant that controls the user's Android phone. The user speaks Hindi, English or Hinglish.
Reply with ONLY one JSON object, nothing else, in this shape:
{"speak":"short spoken reply","actions":[ ... ]}

"speak": one or two short sentences. If the user spoke Hindi/Hinglish, reply in Hindi using Devanagari script. Otherwise reply in English.
"actions": a list (can be empty for normal chat). Each action is one of:
{"type":"open_app","name":"app name in English"}
{"type":"whatsapp_send","contact":"contact name in English/Latin letters","phone":"optional number with country code","message":"text"}
{"type":"play_music","query":"song or artist"}   (plays on YouTube Music)
{"type":"media","cmd":"play|pause|play_pause|next|previous|stop"}
{"type":"volume","dir":"up|down|mute|unmute"}
{"type":"call","contact":"name in Latin letters","phone":"optional number"}
{"type":"web_search","query":"text"}
{"type":"open_url","url":"https://..."}
{"type":"timer","seconds":60}
{"type":"flashlight","on":true}
{"type":"tap","text":"visible text of the button on screen"}
{"type":"type","text":"text to type in the focused input box"}
{"type":"scroll","dir":"down|up"}
{"type":"system","cmd":"back|home|recents|notifications|quick_settings|lock|screenshot"}

Rules: Write contact names in Latin letters (Rahul, not राहुल). Never invent phone numbers; use "contact" unless the user said a number. Use only the types above. If the request is just a question or chat, answer in "speak" with an empty actions list.
"""

    fun ask(apiKey: String, model: String, userText: String): JSONObject {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", userText)))
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 0.2))

        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("API error $code: " + text.take(300))

        val out = JSONObject(text)
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
            .getString("text")
        val clean = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return JSONObject(clean)
    }
}
